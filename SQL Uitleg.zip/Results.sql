Explain: 
I created some example data from a hypothetical company selling products to customers.
The company uses SQL Server, which I know very well, the syntax and exact implementation is SQL Server specific,
the ideas translate well to pretty much any relational database in some shape or form.

We assume performance is not a limitation, if this is the case certain choices should be revised.

/* 
BASE OF THE TABLE
    Temp tables are materialised. Therefore you copy and store data which impacts performance, potentially significantly. 
    There is a trade-off between performance and redability/debug-ability. Alternative: Common Table Expression (CTE)
 */
DROP TABLE IF EXISTS #sales_fact;

SELECT
      Order_id
    , Customer_id
    , Product_id
    , Region_id
    , agent_id
INTO #sales_fact
FROM sales_fact;

/* Count of base */
-- SELECT 
--     COUNT(*) AS row_cnt, 
--     COUNT( DISTINCT Order_id) AS dst_order_cnt
-- FROM #sales_fact;


/* Get current sales_office to the region */
DROP TABLE IF EXISTS #active_sales_office;

WITH latest_region_change (
    SELECT
          Region_id
        , start_date_office = MAX(Start_date_office)
    FROM Sales_office_data
    GROUP BY Region_id)

SELECT
      sod.Region_id
    , sod.Sales_office
INTO #active_sales_office
FROM Sales_office_data sod
INNER JOIN latest_region_change e ON d.Region_id = e.Region_id AND  d.start_date = e.Start_date

/* QA */
-- SELECT 
--     COUNT(*) AS row_cnt
--     , COUNT( DISTINCT Region_id)
-- FROM #active_sales_office


/* Bring all together */
drop table if exists tableau_dashboards.sales_customer_agent;

SELECT
      sf.Order_id
    , sf.Customer_id
    , cd.Customer_FirstName
    , cd.Customer_LastName
    , pd.Product
    , Sale_office
    , adata.Agent_Id
    , adata.Agent_Name
    , Agent_active = COALESCE(Agent_Active, 'Online Sale')
INTO tableau_dashboards.sales_customer_agent
FROM #sales_fact sf
-- LEFT JOIN  customer_dim cd 
--     ON sf.Customer_Id = cd.Customer_Id
-- LEFT JOIN product_dim pd
--     ON sf.Product_Id = pd.Product_Id
-- LEFT JOIN Agent_data adata 
--     on sf.Agent_Id = adata.agent_id;


/* QA count, compare with initial */
-- Add join by join and repeat count
SELECT 
    COUNT(*) AS row_cnt, 
    COUNT( DISTINCT Order_id) AS dst_order_cnt
FROM tableau_dashboards.sales_customer_agent;
